var express = require('express');
var router = express.Router();
const Sequelize = require('sequelize');

const sequelize = new Sequelize('Inventario', 'postgres', '1234', {
  host: '192.168.7.133',
  dialect: 'postgres',
  operatorsAliases: false,

  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  },
});

sequelize
.authenticate()
.then(() => {
  console.log('Connection has been established successfully.');
})
.catch(err => {
  console.error('Unable to connect to the database:', err);
});


//modelos de tablas
//Tabla Usuario

const User = sequelize.define('Usuario', {
  usuario: {
    type: Sequelize.STRING
  },
  contraseña: {
    type: Sequelize.STRING
  }
});

//tabla Plataformas
const Plataforma = sequelize.define('Plataformas', {
  placa: {
    type: Sequelize.STRING
  },
  version: {
    type: Sequelize.STRING
  }
});

//tabla Proveedores
const Proveedor = sequelize.define('Proveedores', {
  nombreProveedor: {
    type: Sequelize.STRING
  },
  direccion: {
    type: Sequelize.STRING
  },
  telefono: {
    type: Sequelize.STRING
  },
  horario: {
    type: Sequelize.STRING
  },
  contactosWeb: {
    type: Sequelize.STRING
  },
  sucursal: {
    type: Sequelize.STRING
  },
  sector: {
    type: Sequelize.STRING
  }
});

// tabla tipoProductos
const tipoProducto = sequelize.define('tipoProductos', {
  nombreProducto: {
    type: Sequelize.STRING
  }
});

//tabla Productos
const Producto  = sequelize.define('Productos', {
  nombreProducto: {
    type: Sequelize.STRING
  },
  precioUnitario: {
    type: Sequelize.STRING
  },
  tipo_id: {
    type: Sequelize.INTEGER,
    references: {
      model: tipoProducto,
      key: "id"
    },
    associate: function(modelos){
      modelos.Producto.hasMany(modelos.tipoProducto)
    }
  },
  plataforma_id: {
    type: Sequelize.INTEGER,
    references: {
      model: Plataforma,
      key: "id"
    },
    associate: function(modelos){
      modelos.Producto.hasOne(modelos.Plataforma)
    }
  }
});

// tabla ProductorxProveedor
const ProductosxProveedor = sequelize.define('ProductosxProveedor', {
      proveedor_id: {
        type: Sequelize.INTEGER,
        references: {
          model: Proveedor,
          key: "id"
        },
        associate: function(modelos){
          modelos.ProductosxProveedor.hasMany(modelos.Proveedor)
        }
      },
      producto_id: {
        type: Sequelize.INTEGER,
        references: {
          model: Producto,
          key: "id"
        },
        associate: function(modelos){
          modelos.ProductosxProveedor.hasMany(modelos.Producto)
        }
      }
  });
  
// tabla detalleFacturas
const detalleFactura = sequelize.define('detalleFacturas', {
  precio: {
    type: Sequelize.STRING
  },
  cantidad: {
    type: Sequelize.STRING
  },
  valorTotal: {
    type: Sequelize.STRING
  },
  producto_id: {
    type: Sequelize.INTEGER,
    references: {
      model: Producto,
      key: "id"
    },
    associate: function(modelos){
      modelos.detalleFactura.hasMany(modelos.Producto)
    }
  }
});

// tabla Facturas
const Factura = sequelize.define('Facturas', {
  numeroFactura: {
    type: Sequelize.STRING
  },
  iva: {
    type: Sequelize.STRING
  },
  total: {
    type: Sequelize.STRING
  },
  subTotal: {
    type: Sequelize.STRING
  },
  detalle_id: {
    type: Sequelize.INTEGER,
    references: {
      model: detalleFactura,
      key: "id"
    },
    associate: function(modelos){
      modelos.Factura.hasOne(modelos.detalleFactura)
    }
  }
});


/*
// force: true will drop the table if it already exists Usuario
User.sync({force: true}).then(() => {
  // Table created
  return User.create({
    usuario: 'Esteban',
    contraseña: 'esteban12345',
  });
}); 

// force: true will drop the table if it already exists Plataformas
Plataforma.sync({force: true}).then(() => {
  // Table created
  return Plataforma.create({
    placa: 'Arduino',
    version: 'Leonardo'
  });
});

// force: true will drop the table if it already exists Productos
Producto.sync({force: true}).then(() => {
  // Table created
  return Producto.create({
    nombreProducto: 'Sensor',
    precioUnitario: '5.00'
  });
});



// force: true will drop the table if it already exists Proveedores
Proveedor.sync({force: true}).then(() => {
  // Table created
  return Proveedor.create({
    nombreProveedor: 'Electronica Nacional',
    direccion: 'Colon',
    telefono: '3552147',
    horario: '7:00 am',
    contactosWeb: 'www.electronica@hotmail.com',
    sucursal: ' EN 2',
    sector: 'Sur'
    
  });
});

ProductosxProveedor.sync({force: true}).then(() => {
    // Table created
    return ProductosxProveedor.create({
  
    });
  });

// force: true will drop the table if it already exists tipoProductos
tipoProducto.sync({force: true}).then(() => {
  // Table created
  return tipoProducto.create({
    nombreProducto: 'Arduino'
   
  });
});


// force: true will drop the table if it already exists Facturas
Factura.sync({force: true}).then(() => {
  // Table created
  return Factura.create({
    numeroFactura: '001',
    iva: '12',
    total:'35.00',
    subTotal: '32.00'
  });
});



// force: true will drop the table if it already exists detallefactura.
detalleFactura.sync({force: true}).then(() => {
  // Table created
  return detalleFactura.create({
    precio: '8.00',
    cantidad: '4',
    valorTotal:'32.00'
  });
});
*/


/* GET home page. */
router.get('/config' ,function(req, res,next){
  User.findAll().then(users => {
    console.log(users)
  })
  res.render('index');
});

//CRUD USUARIO
//Usuario -> todos los usuarios
router.get('/Usuario', function(req, res, next) {
  User.findAll().then(users => {
      res.send(users);
  })
});

//Usuarios/add -> añadir un nuevo usuario
router.get('/Usuario/add', function(req, res, next) {
  User.build({
    usuario: 'Henry',
    contraseña: '1234'
  }).save()
  .then(user => {
    res.send(user);
  })
  .catch(error => {
    console.log(error)
  })

});

//Usuarios/update -> modificar unicamente el nombre
router.get('/Usuario/update', function(req, res, next) {
  User.findById(7).then(userId =>{
    if(userId != null){
      userId.update({usuario:"Pepito",contraseña: userId.contraseña})
        .then(update =>{
          res.send(update);
        })
        .catch(error => {
          console.log(error)
        });
    }else{
      res.send({error: "No encontrado para actualizar"});
    }
  }).catch(error => {
    console.log(error)
  });
});

//Usuarios/delete -> eliminar el usuario cualquiera
router.get('/Usuario/delete', function(req, res, next) {
  
   User.findById(5).then(userId =>{
    if(userId != null){ 
    userId.destroy()
     .then(destroy =>{
       console.log(req);
       res.send(destroy)
     })
     .catch(error => {
      console.log(error)
    });
  }else{
    res.send({error: "No encontrado para eliminar"});
    }
  }).catch(error => {
    console.log(error)
  });
});


//CRUD PLATAFORMAS
//Plataforma -> todos las plataformas
router.get('/Plataforma', function(req, res, next) {
  User.findAll().then(plataforma => {
      res.send(plataforma);
  })
});

//Plataformas/add -> añadir un nueva plataforma
router.get('/Plataforma/add', function(req, res, next) {
  User.build({
      placa: 'Arduino',
    version: 'Leonardo'
  }).save()
  .then(user => {
    res.send(Plataforma);
  })
  .catch(error => {
    console.log(error)
  })

});

//Plataforma/update -> modificar 
router.get('/Plataforma/update', function(req, res, next) {
  User.findById(7).then(id =>{
    if(userId != null){
      userId.update({ placa: 'Arduino',version: 'UNO'})
        .then(update =>{
          res.send(update);
        })
        .catch(error => {
          console.log(error)
        });
    }else{
      res.send({error: "No encontrado para actualizar"});
    }
  }).catch(error => {
    console.log(error)
  });
});

//Plataforma/delete -> eliminar 
router.get('/Plataforma/delete', function(req, res, next) {
  
   User.findById(1).then(id =>{
    if(id != null){ 
    id.destroy()
     .then(destroy =>{
       console.log(req);
       res.send(destroy)
     })
     .catch(error => {
      console.log(error)
    });
  }else{
    res.send({error: "No encontrado para eliminar"});
    }
  }).catch(error => {
    console.log(error)
  });
});


//CRUD PROVEEDORES
//Proveedor -> todos los proveedores
router.get('/Proveedor', function(req, res, next) {
  User.findAll().then(proveedor => {
      res.send(proveedor);
  })
});

//Proveedor/add -> añadir un nuevo proveedor
router.get('/Proveedor/add', function(req, res, next) {
  User.build({
    nombreProveedor: 'Electronica Nacional',
    direccion: 'Colon',
    telefono: '35765434',
    horario: '10:00 am',
    contactosWeb: 'www.electronica@hotmail.com',
    sucursal: ' EN 4',
    sector: 'CENTRO'
  }).save()
  .then(user => {
    res.send(Proveedor);
  })
  .catch(error => {
    console.log(error)
  })

});

//Proveedor/update -> modificar 
router.get('/Proveedor/update', function(req, res, next) {
  User.findById(7).then(id =>{
    if(userId != null){
      userId.update({ nombreProveedor: 'EL LED',telefono: '3456972', sucursal: ' EN 6'})
        .then(update =>{
          res.send(update);
        })
        .catch(error => {
          console.log(error)
        });
    }else{
      res.send({error: "No encontrado para actualizar"});
    }
  }).catch(error => {
    console.log(error)
  });
});

//Proveedor/delete -> eliminar
router.get('/Proveedor/delete', function(req, res, next) {
  
   User.findById(1).then(id =>{
    if(id != null){ 
    id.destroy()
     .then(destroy =>{
       console.log(req);
       res.send(destroy)
     })
     .catch(error => {
      console.log(error)
    });
  }else{
    res.send({error: "No encontrado para eliminar"});
    }
  }).catch(error => {
    console.log(error)
  });
});


//CRUD TIPO PRODUCTO
//Producto -> todos los tipos de producto
router.get('/Producto', function(req, res, next) {
  User.findAll().then(productor => {
      res.send(producto);
  })
});

//Producto/add -> añadir un nuevo tipo de  producto
router.get('/Producto/add', function(req, res, next) {
  User.build({
    nombreProducto: 'Sensor',
    
  }).save()
  .then(user => {
    res.send(TipoProducto);
  })
  .catch(error => {
    console.log(error)
  })

});

//Producto/update -> modificar 
router.get('/Producto/update', function(req, res, next) {
  User.findById(7).then(id =>{
    if(userId != null){
      userId.update({ nombreProducto: 'LED'})
        .then(update =>{
          res.send(update);
        })
        .catch(error => {
          console.log(error)
        });
    }else{
      res.send({error: "No encontrado para actualizar"});
    }
  }).catch(error => {
    console.log(error)
  });
});

//Producto/delete -> eliminar 
router.get('/Producto/delete', function(req, res, next) {
  
   User.findById(1).then(id =>{
    if(id != null){ 
    id.destroy()
     .then(destroy =>{
       console.log(req);
       res.send(destroy)
     })
     .catch(error => {
      console.log(error)
    });
  }else{
    res.send({error: "No encontrado para eliminar"});
    }
  }).catch(error => {
    console.log(error)
  });
});

//CRUD FACTURA
//Factura-> todos las facturas
router.get('/Factura', function(req, res, next) {
  User.findAll().then(factura => {
      res.send(factura);
  })
});

//Factura/add -> añadir una nueva factura
router.get('/Factura/add', function(req, res, next) {
  User.build({
    numeroFactura: '001',
    iva: '12',
    total:'35.00',
    subTotal: '32.00'
  }).save()
  .then(user => {
    res.send(Factura);
  })
  .catch(error => {
    console.log(error)
  })

});

//Factura/update -> modificar 
router.get('/Factura/update', function(req, res, next) {
  User.findById(7).then(id =>{
    if(userId != null){
      userId.update({numeroFactura: '011', total:'36.00'})
        .then(update =>{
          res.send(update);
        })
        .catch(error => {
          console.log(error)
        });
    }else{
      res.send({error: "No encontrado para actualizar"});
    }
  }).catch(error => {
    console.log(error)
  });
});

//Factura/delete -> eliminar 
router.get('/Factura/delete', function(req, res, next) {
  
   User.findById(1).then(id =>{
    if(id != null){ 
    id.destroy()
     .then(destroy =>{
       console.log(req);
       res.send(destroy)
     })
     .catch(error => {
      console.log(error)
    });
  }else{
    res.send({error: "No encontrado para eliminar"});
    }
  }).catch(error => {
    console.log(error)
  });
});


//CRUD DETALLE FACTURA
//detalleFacturas-> todos los detalles de factura
router.get('/detalleFacturas', function(req, res, next) {
  User.findAll().then(detalleFacturas => {
      res.send(detalleFacturas);
  })
});

//detalleFacturas/add -> añadir un nuevo detalleFactura
router.get('/detalleFacturas/add', function(req, res, next) {
  User.build({
    numeroFactura: '001',
     precio: '9.00',
     cantidad: '4',
     valorTotal:'36.00'
  }).save()
  .then(user => {
    res.send(detalleFacturas);
  })
  .catch(error => {
    console.log(error)
  })

});

//detalleFacturas/update -> modificar 
router.get('/detalleFacturas/update', function(req, res, next) {
  User.findById(7).then(id =>{
    if(userId != null){
      userId.update({precio: '10.00', valorTotal:'40.00'})
        .then(update =>{
          res.send(update);
        })
        .catch(error => {
          console.log(error)
        });
    }else{
      res.send({error: "No encontrado para actualizar"});
    }
  }).catch(error => {
    console.log(error)
  });
});

//detalleFacturas/delete -> eliminar 
router.get('/detalleFacturas/delete', function(req, res, next) {
  
   User.findById(1).then(id =>{
    if(id != null){ 
    id.destroy()
     .then(destroy =>{
       console.log(req);
       res.send(destroy)
     })
     .catch(error => {
      console.log(error)
    });
  }else{
    res.send({error: "No encontrado para eliminar"});
    }
  }).catch(error => {
    console.log(error)
  });
});


//CRUD PRODUCTO
//Producto-> todos los productos
router.get('/Producto', function(req, res, next) {
  User.findAll().then(producto => {
      res.send(producto);
  })
});

//Producto/add -> añadir un nuevo usuario
router.get('/Producto/add', function(req, res, next) {
  User.build({
    nombreProducto: 'Sensor',
    precioUnitario: '5.00'
  }).save()
  .then(user => {
    res.send(Producto);
  })
  .catch(error => {
    console.log(error)
  })

});

//dProducto/update -> modificar unicamente el nombre
router.get('/Producto/update', function(req, res, next) {
  User.findById(7).then(id =>{
    if(userId != null){
      userId.update({nombreProducto: 'Actuador',precioUnitario: '3.00'})
        .then(update =>{
          res.send(update);
        })
        .catch(error => {
          console.log(error)
        });
    }else{
      res.send({error: "No encontrado para actualizar"});
    }
  }).catch(error => {
    console.log(error)
  });
});

//Producto/delete -> eliminar el usuario cualquiera
router.get('/Producto/delete', function(req, res, next) {
  
   User.findById(1).then(id =>{
    if(id != null){ 
    id.destroy()
     .then(destroy =>{
       console.log(req);
       res.send(destroy)
     })
     .catch(error => {
      console.log(error)
    });
  }else{
    res.send({error: "No encontrado para eliminar"});
    }
  }).catch(error => {
    console.log(error)
  });
});



router.get('/hola',function(req,res,next){
  res.render('index', { title: 'Hola mundo' });
});


module.exports = router;

