var express = require('express');
var router = express.Router();
const Sequelize = require('sequelize');

const sequelize = new Sequelize('Inventario', 'postgres', '1234', {
  host: '192.168.7.133',
  dialect: 'postgres',
  operatorsAliases: false,

  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  },
});

sequelize
.authenticate()
.then(() => {
  console.log('Connection has been established successfully.');
})
.catch(err => {
  console.error('Unable to connect to the database:', err);
});


//modelos de tablas
//Tabla Usuario

const User = sequelize.define('Usuario', {
  usuario: {
    type: Sequelize.STRING
  },
  contraseña: {
    type: Sequelize.STRING
  }
});

//tabla Plataformas
const Plataforma = sequelize.define('Plataformas', {
  placa: {
    type: Sequelize.STRING
  },
  version: {
    type: Sequelize.STRING
  }
});

//tabla Proveedores
const Proveedor = sequelize.define('Proveedores', {
  nombreProveedor: {
    type: Sequelize.STRING
  },
  direccion: {
    type: Sequelize.STRING
  },
  telefono: {
    type: Sequelize.STRING
  },
  horario: {
    type: Sequelize.STRING
  },
  contactosWeb: {
    type: Sequelize.STRING
  },
  sucursal: {
    type: Sequelize.STRING
  },
  sector: {
    type: Sequelize.STRING
  }
});

// tabla tipoProductos
const tipoProducto = sequelize.define('tipoProductos', {
  nombreProducto: {
    type: Sequelize.STRING
  }
});

//tabla Productos
const Producto  = sequelize.define('Productos', {
  nombreProducto: {
    type: Sequelize.STRING
  },
  precioUnitario: {
    type: Sequelize.STRING
  },
  tipo_id: {
    type: Sequelize.INTEGER,
    references: {
      model: tipoProducto,
      key: "id"
    },
    associate: function(modelos){
      modelos.Producto.hasMany(modelos.tipoProducto)
    }
  },
  plataforma_id: {
    type: Sequelize.INTEGER,
    references: {
      model: Plataforma,
      key: "id"
    },
    associate: function(modelos){
      modelos.Producto.hasOne(modelos.Plataforma)
    }
  }
});

// tabla ProductorxProveedor
const ProductosxProveedor = sequelize.define('ProductosxProveedor', {
      proveedor_id: {
        type: Sequelize.INTEGER,
        references: {
          model: Proveedor,
          key: "id"
        },
        associate: function(modelos){
          modelos.ProductosxProveedor.hasMany(modelos.Proveedor)
        }
      },
      producto_id: {
        type: Sequelize.INTEGER,
        references: {
          model: Producto,
          key: "id"
        },
        associate: function(modelos){
          modelos.ProductosxProveedor.hasMany(modelos.Producto)
        }
      }
  });
  
// tabla detalleFacturas
const detalleFactura = sequelize.define('detalleFacturas', {
  precio: {
    type: Sequelize.STRING
  },
  cantidad: {
    type: Sequelize.STRING
  },
  valorTotal: {
    type: Sequelize.STRING
  },
  producto_id: {
    type: Sequelize.INTEGER,
    references: {
      model: Producto,
      key: "id"
    },
    associate: function(modelos){
      modelos.detalleFactura.hasMany(modelos.Producto)
    }
  }
});

// tabla Facturas
const Factura = sequelize.define('Facturas', {
  numeroFactura: {
    type: Sequelize.STRING
  },
  iva: {
    type: Sequelize.STRING
  },
  total: {
    type: Sequelize.STRING
  },
  subTotal: {
    type: Sequelize.STRING
  },
  detalle_id: {
    type: Sequelize.INTEGER,
    references: {
      model: detalleFactura,
      key: "id"
    },
    associate: function(modelos){
      modelos.Factura.hasOne(modelos.detalleFactura)
    }
  }
});


/*
// force: true will drop the table if it already exists Usuario
User.sync({force: true}).then(() => {
  // Table created
  return User.create({
    usuario: 'Esteban',
    contraseña: 'esteban12345',
  });
}); 

// force: true will drop the table if it already exists Plataformas
Plataforma.sync({force: true}).then(() => {
  // Table created
  return Plataforma.create({
    placa: 'Arduino',
    version: 'Leonardo'
  });
});

// force: true will drop the table if it already exists Productos
Producto.sync({force: true}).then(() => {
  // Table created
  return Producto.create({
    nombreProducto: 'Sensor',
    precioUnitario: '5.00'
  });
});



// force: true will drop the table if it already exists Proveedores
Proveedor.sync({force: true}).then(() => {
  // Table created
  return Proveedor.create({
    nombreProveedor: 'Electronica Nacional',
    direccion: 'Colon',
    telefono: '3552147',
    horario: '7:00 am',
    contactosWeb: 'www.electronica@hotmail.com',
    sucursal: ' EN 2',
    sector: 'Sur'
    
  });
});

ProductosxProveedor.sync({force: true}).then(() => {
    // Table created
    return ProductosxProveedor.create({
  
    });
  });

// force: true will drop the table if it already exists tipoProductos
tipoProducto.sync({force: true}).then(() => {
  // Table created
  return tipoProducto.create({
    nombreProducto: 'Arduino'
   
  });
});


// force: true will drop the table if it already exists Facturas
Factura.sync({force: true}).then(() => {
  // Table created
  return Factura.create({
    numeroFactura: '001',
    iva: '12',
    total:'35.00',
    subTotal: '32.00'
  });
});



// force: true will drop the table if it already exists
detalleFactura.sync({force: true}).then(() => {
  // Table created
  return detalleFactura.create({
    precio: '8.00',
    cantidad: '4',
    valorTotal:'32.00'
  });
});
*/


/* GET home page. */
router.get('/config' ,function(req, res,next){
  User.findAll().then(users => {
    console.log(users)
  })
  res.render('index');
});


//Usuario -> todos los usuarios
router.get('/Usuario', function(req, res, next) {
  User.findAll().then(users => {
      res.send(users);
  })
});

//Usuarios/add -> añadir un nuevo usuario
router.get('/Usuario/add', function(req, res, next) {
  User.build({
    usuario: 'Henry',
    contraseña: '1234'
  }).save()
  .then(user => {
    res.send(user);
  })
  .catch(error => {
    console.log(error)
  })

});

//Usuarios/update -> modificar unicamente el nombre
router.get('/Usuario/update', function(req, res, next) {
  User.findById(7).then(userId =>{
    if(userId != null){
      userId.update({usuario:"Pepito",contraseña: userId.contraseña})
        .then(update =>{
          res.send(update);
        })
        .catch(error => {
          console.log(error)
        });
    }else{
      res.send({error: "No encontrado para actualizar"});
    }
  }).catch(error => {
    console.log(error)
  });
});

//Usuarios/delete -> eliminar el usuario cualquiera
router.get('/Usuario/delete', function(req, res, next) {
  
   User.findById(5).then(userId =>{
    if(userId != null){ 
    userId.destroy()
     .then(destroy =>{
       console.log(req);
       res.send(destroy)
     })
     .catch(error => {
      console.log(error)
    });
  }else{
    res.send({error: "No encontrado para eliminar"});
    }
  }).catch(error => {
    console.log(error)
  });
});








router.get('/hola',function(req,res,next){
  res.render('index', { title: 'Hola mundo' });
});


module.exports = router;

